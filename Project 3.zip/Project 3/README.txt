to compile, do 'javac ChainedSystem.java ContiguousSystem.java DiskDrive.java FileEntry.java FileSystem.java FileTable.java IndexedSystem.java UserInterface.java'

The UserInterface.java is the driver file that is to be run when everything is compiled.


to run the code, use 'java UserInterface <file allocation method>'